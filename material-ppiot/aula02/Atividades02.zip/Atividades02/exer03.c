#include <stdio.h>

int main() {
    // Imprimir o nome completo
    printf("Nome completo: Seu Nome Completo\n"); // Substitua 'Seu Nome Completo' pelo seu nome completo
    
    // Informar o sistema operacional usado
    printf("Sistema operacional: Seu Sistema Operacional\n"); // Substitua 'Seu Sistema Operacional' pelo sistema operacional que você usa
    
    // Informar a idade
    printf("Idade: Sua Idade\n"); // Substitua 'Sua Idade' pela sua idade

    return 0;
}
