#include <stdio.h>

int main() {
    printf("Olá, SeuNome!\n"); // Substitua 'SeuNome' pelo seu nome
    return 0;
}
