
#include <stdio.h>

int main() {
    printf("Bem-vindo a Natal!\n");
    printf("Em Natal faz calor o ano inteiro.\n");
    return 0;
}
