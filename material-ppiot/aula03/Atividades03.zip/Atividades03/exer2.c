#include <stdio.h>

int main() {
    int var = 100;
    printf("Valor inicial de var: %d\n", var);

    var = 200;
    printf("Novo valor de var: %d\n", var);

    return 0;
}
